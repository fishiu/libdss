create definer = root@localhost view usual_user as
(
select `libdss`.`users`.`userID`                                                                                   AS `userID`,
       `libdss`.`users`.`gender`                                                                                   AS `gender`,
       if((not (`libdss`.`users`.`userID` in (select `libdss`.`attence`.`userID` from `libdss`.`attence`))), 0,
          1)                                                                                                       AS `isUsual`
from `libdss`.`users`
group by `libdss`.`users`.`userID`);

