create definer = root@localhost view age_attence as
(
select timestampdiff(YEAR, `libdss`.`users`.`birthday`, curdate()) AS `age`,
       `libdss`.`users`.`userID`                                   AS `userID`,
       `libdss`.`users`.`gender`                                   AS `gender`,
       sum(timestampdiff(MINUTE, `a`.`entime`, `a`.`lftime`))      AS `dureTime`
from (`libdss`.`users`
         join `libdss`.`attence` `a` on ((`libdss`.`users`.`userID` = `a`.`userID`)))
group by `libdss`.`users`.`userID`);

