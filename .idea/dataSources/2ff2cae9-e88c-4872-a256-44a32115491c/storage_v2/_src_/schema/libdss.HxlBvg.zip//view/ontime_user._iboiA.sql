create definer = root@localhost view ontime_user as
(
select `libdss`.`users`.`userID`                                                                    AS `userID`,
       `libdss`.`users`.`gender`                                                                    AS `gender`,
       if((not (`libdss`.`users`.`userID` in (select `libdss`.`borecords`.`userID`
                                              from (`libdss`.`borecords`
                                                       join `libdss`.`retrecords`
                                                            on ((`libdss`.`retrecords`.`recordID` = `libdss`.`borecords`.`recordID`)))
                                              where (`libdss`.`retrecords`.`overdue` > 0)))), 0, 1) AS `isOntime`
from `libdss`.`users`
group by `libdss`.`users`.`userID`);

