create definer = root@localhost view during as
select (sum(timestampdiff(MINUTE, `libdss`.`attence`.`entime`, `libdss`.`attence`.`lftime`)) / 60) AS `during`,
       `libdss`.`attence`.`userID`                                                                 AS `userID`
from `libdss`.`attence`
group by `libdss`.`attence`.`userID`;

