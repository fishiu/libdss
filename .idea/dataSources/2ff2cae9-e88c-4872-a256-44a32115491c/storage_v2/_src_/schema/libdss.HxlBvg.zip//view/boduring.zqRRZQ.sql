create definer = root@localhost view boduring as
select sum(timestampdiff(DAY, `libdss`.`borecords`.`lentdate`, `libdss`.`borecords`.`duedate`)) AS `during`,
       `libdss`.`borecords`.`userID`                                                            AS `userID`
from `libdss`.`borecords`
group by `libdss`.`borecords`.`userID`;

