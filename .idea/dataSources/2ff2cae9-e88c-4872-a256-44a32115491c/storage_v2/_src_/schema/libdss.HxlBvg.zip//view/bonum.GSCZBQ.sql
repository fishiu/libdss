create definer = root@localhost view bonum as
select count(`libdss`.`borecords`.`userID`) AS `bonum`
from `libdss`.`borecords`
group by `libdss`.`borecords`.`userID`;

