create definer = root@localhost view user_age_gender as
select `libdss`.`users`.`userID`                                   AS `userID`,
       timestampdiff(YEAR, `libdss`.`users`.`birthday`, curdate()) AS `age`,
       `libdss`.`users`.`gender`                                   AS `gender`
from `libdss`.`users`;

