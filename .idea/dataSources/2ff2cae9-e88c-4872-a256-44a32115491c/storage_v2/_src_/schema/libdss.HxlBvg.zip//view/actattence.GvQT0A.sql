create definer = root@localhost view actattence as
select `libdss`.`activity`.`actID`   AS `actID`,
       `libdss`.`activity`.`actype`  AS `actype`,
       `libdss`.`actdetail`.`userID` AS `userID`
from (`libdss`.`activity`
         join `libdss`.`actdetail`);

