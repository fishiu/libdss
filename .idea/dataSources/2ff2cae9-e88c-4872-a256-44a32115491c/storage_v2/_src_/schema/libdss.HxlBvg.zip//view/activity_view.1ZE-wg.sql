create definer = root@localhost view activity_view as
select `libdss`.`activity`.`actype`                 AS `actype`,
       month(`libdss`.`actdetail`.`startTime`)      AS `mon`,
       dayofmonth(`libdss`.`actdetail`.`startTime`) AS `da`,
       `libdss`.`actdetail`.`userID`                AS `userID`
from `libdss`.`activity`
         join `libdss`.`actdetail`
where (`libdss`.`activity`.`actID` = `libdss`.`actdetail`.`actID`);

