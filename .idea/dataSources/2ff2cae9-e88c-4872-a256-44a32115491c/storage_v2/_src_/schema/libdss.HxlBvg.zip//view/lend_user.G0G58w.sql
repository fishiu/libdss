create definer = root@localhost view lend_user as
(
select `libdss`.`users`.`userID` AS `userID`,
       `libdss`.`users`.`gender` AS `gender`,
       if((not (`libdss`.`users`.`userID` in (select `libdss`.`borecords`.`userID` from `libdss`.`borecords`))), 0,
          1)                     AS `isLend`
from `libdss`.`users`
group by `libdss`.`users`.`userID`);

