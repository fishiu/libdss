create definer = root@localhost view ennum as
select count(0) AS `time_attence`, `libdss`.`attence`.`entime` AS `time`
from `libdss`.`attence`
group by `libdss`.`attence`.`entime`;

